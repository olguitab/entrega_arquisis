#!/bin/bash

echo "Stop Aplication"
docker compose --file docker-compose.production.yml down